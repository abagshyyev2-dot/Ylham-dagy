import fs from 'node:fs';import vm from 'node:vm';
const source=fs.readFileSync('public/app.js','utf8').split('const selected=new Set()')[0];
const {products,translations}=vm.runInNewContext(source+';({products,translations})',{document:{querySelectorAll:()=>[]}});
const seed=products.map(p=>({id:p.id,kind:'product',published:true,version:1,data:{code:p.code,category:p.category,weight:25,planned:p.planned,image:'/assets/'+p.id+'.svg',name:Object.fromEntries(['ru','tk','en'].map(l=>[l,translations[l]['product'+p.n]])),description:Object.fromEntries(['ru','tk','en'].map(l=>[l,translations[l]['desc'+p.n]])),specs:{water:'',consumption:'',layer:'',temperature:''}}}));
fs.writeFileSync('server/catalog-seed.json',JSON.stringify(seed,null,2));console.log('Seed prepared:',seed.length);
