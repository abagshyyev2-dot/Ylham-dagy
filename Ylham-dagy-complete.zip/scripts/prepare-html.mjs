import fs from 'node:fs';
for(const [source,target]of[['public/index.html','server/site-html.json'],['server/admin.html','server/admin-html.json']])fs.writeFileSync(target,JSON.stringify(fs.readFileSync(source,'utf8')));
