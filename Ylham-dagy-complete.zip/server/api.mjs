import seed from './catalog-seed.json' with {type:'json'};
const kinds=['product','store','partner','video','settings'];
const statuses=['new','processing','closed','spam','archived'];
const categories=['adhesive','floor','walls','masonry','facade','grout'];
const now=()=>new Date().toISOString();
class APIError extends Error{constructor(status,message){super(message);this.status=status;}}
const bad=(message)=>{throw new APIError(400,message);};
export function isAdmin(request,env){const id=request.headers.get('oai-authenticated-user-id');const email=request.headers.get('oai-authenticated-user-email');return !!(id&&email&&env.ADMIN_EMAIL&&email.toLowerCase()===env.ADMIN_EMAIL.trim().toLowerCase());}
function requireAdmin(request,env){if(!request.headers.get('oai-authenticated-user-id'))throw new APIError(401,'Войдите в аккаунт владельца.');if(!isAdmin(request,env))throw new APIError(403,'Доступ разрешён только владельцу сайта.');}
function json(data,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
const text=(v,max=500,required=false)=>{if(v===undefined||v===null)v='';if(typeof v!=='string')bad('Ожидалось текстовое значение.');v=v.trim();if(v.length>max)bad(`Текст не должен превышать ${max} символов.`);if(required&&!v)bad('Заполните обязательные поля.');return v;};
function localized(v,max,required=false){if(!v||typeof v!=='object'||Array.isArray(v))bad('Укажите тексты на трёх языках.');return Object.fromEntries(['ru','tk','en'].map(l=>[l,text(v[l],max,required)]));}
function url(v,required=false){v=text(v,1200,required);if(!v)return '';if(/^\/assets\/[a-zA-Z0-9_./-]+$/.test(v)&&!v.includes('..'))return v;let u;try{u=new URL(v);}catch{bad('Укажите полный HTTPS-адрес.');}if(u.protocol!=='https:'||u.username||u.password)bad('Допускаются только HTTPS-ссылки.');return u.href;}
function number(v,min,max){if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)bad(`Число должно быть от ${min} до ${max}.`);return v;}
export function validateContent(kind,d){
 if(!d||typeof d!=='object'||Array.isArray(d))bad('Некорректные данные.');
 if(kind==='product'){
  const code=text(d.code,6,true);if(!/^\d{3,6}$/.test(code))bad('Код продукта должен содержать 3–6 цифр.');if(!categories.includes(d.category))bad('Выберите категорию продукта.');
  return {code,category:d.category,weight:number(d.weight,.1,1000),planned:!!d.planned,image:url(d.image,true),name:localized(d.name,160,true),description:localized(d.description,1200),specs:Object.fromEntries(['water','consumption','layer','temperature'].map(k=>[k,text(d.specs?.[k],150)]))};
 }
 if(kind==='store'){
  if(!['retail','office','warehouse'].includes(d.type))bad('Выберите тип точки продаж.');
  return {name:localized(d.name,160,true),address:localized(d.address,500,true),city:text(d.city,80,true),type:d.type,coords:[number(d.coords?.[0],35,43),number(d.coords?.[1],52,67)],phone:text(d.phone,50),url:url(d.url)};
 }
 if(kind==='partner')return {name:localized(d.name,160,true),description:localized(d.description,600),logo:url(d.logo),url:url(d.url)};
 if(kind==='video')return {title:localized(d.title,160,true),description:localized(d.description,600),src:url(d.src,true),poster:url(d.poster)};
 if(kind==='settings'){
  const email=text(d.email,200),whatsapp=text(d.whatsapp,30).replace(/[\s()-]/g,''),telegram=text(d.telegram,100).replace(/^@/,'');
  if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))bad('Проверьте email.');if(whatsapp&&!/^\+?[1-9]\d{7,14}$/.test(whatsapp))bad('WhatsApp: номер с кодом страны.');if(telegram&&!/^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(telegram))bad('Telegram: имя пользователя без ссылки.');
  return {email,whatsapp,telegram,phone:text(d.phone,50),address:localized(d.address||{},600)};
 }
 bad('Неизвестный тип записи.');
}
async function readJSON(request){
 if(request.headers.get('x-ylham-request')!=='1')throw new APIError(403,'Недопустимый запрос.');
 const origin=request.headers.get('origin');if(origin!==new URL(request.url).origin)throw new APIError(403,'Запрос с другого сайта запрещён.');
 if(!(request.headers.get('content-type')||'').startsWith('application/json'))throw new APIError(415,'Ожидается JSON.');
 const reader=request.body?.getReader();if(!reader)bad('Пустой запрос.');let bytes=0,parts=[];
 while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.length;if(bytes>32768){await reader.cancel();throw new APIError(413,'Слишком большой запрос.');}parts.push(value);}
 const buf=new Uint8Array(bytes);let offset=0;for(const part of parts){buf.set(part,offset);offset+=part.length;}
 let parsed;try{parsed=JSON.parse(new TextDecoder().decode(buf));}catch{bad('Некорректный JSON.');}
 if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))bad('Ожидается объект с данными.');return parsed;
}
function unpack(row){return {...row,data:JSON.parse(row.data),published:!!row.published};}
function auditStmt(db,request,action,target){return db.prepare('INSERT INTO audit_log(id,actor,action,target,created_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),request.headers.get('oai-authenticated-user-id'),action,target,now());}
export async function handleAPI(request,env){
 try{
  const db=env.DB;if(!db)throw new APIError(503,'База данных временно недоступна.');
  const u=new URL(request.url),path=u.pathname.replace(/\/$/,'');
  if(path==='/api/content'&&request.method==='GET'){
   const rows=(await db.prepare('SELECT * FROM content WHERE published=1 ORDER BY kind,id').all()).results.map(unpack);
   const initialized=await db.prepare("SELECT id FROM content WHERE kind='settings' AND id='main'").first();
   return json({items:initialized?rows:[...seed,...rows],initialized:!!initialized});
  }
  if(path==='/api/inquiries'&&request.method==='POST'){
   const d=await readJSON(request);if(d.website)return json({ok:true,id:crypto.randomUUID()},201);
   if(!['materials','partnership'].includes(d.type))bad('Выберите тип заявки.');
   if(d.consent!==true)bad('Подтвердите согласие на обработку обращения.');
   const name=text(d.name,160,true),contact=text(d.contact,200,true),company=text(d.company,160),city=text(d.city,160),message=text(d.message,3000);
   if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact)&&contact.replace(/\D/g,'').length<7)bad('Укажите email или телефон для ответа.');
   if(!Array.isArray(d.products)||d.products.length>30)bad('Проверьте список товаров.');
   const ids=[...new Set(d.products.map(id=>text(id,80,true)))];let ordered=[];
   if(d.type==='materials'){
    if(!ids.length)bad('Выберите хотя бы один продукт.');
    const rows=(await db.prepare("SELECT * FROM content WHERE kind='product' AND published=1").all()).results.map(unpack);
    const initialized=await db.prepare("SELECT id FROM content WHERE kind='settings' AND id='main'").first();const catalog=initialized?rows:seed;
    ordered=ids.map(id=>{const p=catalog.find(p=>p.id===id);if(!p)bad('Один из продуктов больше недоступен. Обновите каталог.');return {id,code:p.data.code,name:p.data.name.ru};});
   }
   const actor=request.headers.get('oai-authenticated-user-id')||request.headers.get('cf-connecting-ip')||'anonymous';
   const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(actor)))].map(x=>x.toString(16).padStart(2,'0')).join('');
   const bucket=Math.floor(Date.now()/600000);
   const rate=await db.prepare('INSERT INTO rate_limits(key,bucket,count) VALUES(?,?,1) ON CONFLICT(key,bucket) DO UPDATE SET count=count+1 RETURNING count').bind(hash,bucket).first();
   if(rate.count>5)throw new APIError(429,'Слишком много заявок. Попробуйте через 10 минут.');
   const id=crypto.randomUUID(),time=now();
   await db.batch([db.prepare('INSERT INTO inquiries(id,type,name,contact,company,city,message,products,status,notes,version,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?)').bind(id,d.type,name,contact,company,city,message,JSON.stringify(ordered),'new','',time,time),db.prepare('DELETE FROM rate_limits WHERE bucket < ?').bind(bucket-6)]);
   return json({ok:true,id},201);
  }
  if(!path.startsWith('/api/admin'))throw new APIError(404,'Не найдено.');
  requireAdmin(request,env);
  if(path==='/api/admin/me'&&request.method==='GET')return json({admin:true,email:request.headers.get('oai-authenticated-user-email')});
  if(path==='/api/admin/initialize'&&request.method==='POST'){
   await readJSON(request);const time=now(),settings={email:'',whatsapp:'',telegram:'',phone:'',address:{ru:'',tk:'',en:''}};
   // Explicit, idempotent seed operation. Schema is migration-owned.
   const exists=await db.prepare("SELECT id FROM content WHERE kind='settings' AND id='main'").first();
   if(!exists)await db.batch([...seed.map(p=>db.prepare('INSERT OR IGNORE INTO content(kind,id,data,published,version,created_at,updated_at) VALUES(?,?,?,1,1,?,?)').bind('product',p.id,JSON.stringify(p.data),time,time)),db.prepare('INSERT OR IGNORE INTO content(kind,id,data,published,version,created_at,updated_at) VALUES(?,?,?,1,1,?,?)').bind('settings','main',JSON.stringify(settings),time,time),auditStmt(db,request,'initialize','catalog')]);
   return json({ok:true});
  }
  if(path==='/api/admin/dashboard'&&request.method==='GET'){
   const counts=(await db.prepare('SELECT status,COUNT(*) AS count FROM inquiries GROUP BY status').all()).results;
   const content=(await db.prepare('SELECT kind,COUNT(*) AS count FROM content GROUP BY kind').all()).results;
   return json({counts,content});
  }
  if(path==='/api/admin/content'&&request.method==='GET'){
   const kind=u.searchParams.get('kind');if(!kinds.includes(kind))bad('Неизвестный раздел.');return json({items:(await db.prepare('SELECT * FROM content WHERE kind=? ORDER BY id').bind(kind).all()).results.map(unpack)});
  }
  const contentMatch=path.match(/^\/api\/admin\/content\/([a-z]+)\/([a-zA-Z0-9_-]{1,80})$/);
  if(contentMatch&&request.method==='PUT'){
   const [,kind,id]=contentMatch;if(!kinds.includes(kind)||(kind==='settings'&&id!=='main'))bad('Неизвестный раздел.');
   const body=await readJSON(request),data=validateContent(kind,body.data),version=number(body.version,0,1e9);if(!Number.isInteger(version))bad('Неверная версия.');const published=kind==='settings'?1:body.published?1:0,time=now();
   if(version===0){
    const result=await db.prepare('INSERT OR IGNORE INTO content(kind,id,data,published,version,created_at,updated_at) VALUES(?,?,?,?,1,?,?)').bind(kind,id,JSON.stringify(data),published,time,time).run();if(!result.meta.changes)throw new APIError(409,'Запись уже существует. Обновите список.');
   }else{
    const result=await db.prepare('UPDATE content SET data=?,published=?,version=version+1,updated_at=? WHERE kind=? AND id=? AND version=?').bind(JSON.stringify(data),published,time,kind,id,version).run();if(!result.meta.changes)throw new APIError(409,'Запись изменена в другой вкладке. Обновите список перед сохранением.');
   }
   await auditStmt(db,request,'save-content',kind+'/'+id).run();return json({ok:true,item:unpack(await db.prepare('SELECT * FROM content WHERE kind=? AND id=?').bind(kind,id).first())});
  }
  if(path==='/api/admin/inquiries'&&request.method==='GET'){
   const status=u.searchParams.get('status')||'all';if(status!=='all'&&!statuses.includes(status))bad('Неизвестный статус.');const offset=Math.max(0,Math.min(100000,parseInt(u.searchParams.get('offset')||'0')||0));
   const rows=status==='all'?await db.prepare('SELECT * FROM inquiries ORDER BY created_at DESC LIMIT 51 OFFSET ?').bind(offset).all():await db.prepare('SELECT * FROM inquiries WHERE status=? ORDER BY created_at DESC LIMIT 51 OFFSET ?').bind(status,offset).all();
   return json({items:rows.results.slice(0,50).map(r=>({...r,products:JSON.parse(r.products)})),hasMore:rows.results.length>50});
  }
  const inquiryMatch=path.match(/^\/api\/admin\/inquiries\/([a-zA-Z0-9-]{36})$/);
  if(inquiryMatch&&request.method==='PUT'){
   const d=await readJSON(request);if(!statuses.includes(d.status))bad('Неизвестный статус.');const notes=text(d.notes,3000),version=number(d.version,1,1e9);
   const result=await db.prepare('UPDATE inquiries SET status=?,notes=?,version=version+1,updated_at=? WHERE id=? AND version=?').bind(d.status,notes,now(),inquiryMatch[1],version).run();if(!result.meta.changes)throw new APIError(409,'Заявка изменилась. Обновите список.');await auditStmt(db,request,'update-inquiry',inquiryMatch[1]).run();return json({ok:true});
  }
  throw new APIError(404,'Не найдено.');
 }catch(error){if(error instanceof APIError)return json({error:error.message},error.status);console.error('API operation failed',error?.name);return json({error:'Не удалось выполнить операцию. Попробуйте позже.'},500);}
}
