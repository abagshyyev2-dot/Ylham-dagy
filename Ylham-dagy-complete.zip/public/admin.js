const $=s=>document.querySelector(s),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const titles={dashboard:'Обзор',inquiries:'Заявки',product:'Продукция',store:'Точки продаж',partner:'Партнёры',video:'Видео',settings:'Контакты'};
const statusNames={new:'Новая',processing:'В работе',closed:'Завершена',spam:'Спам',archived:'В архиве'};
let section='dashboard',items=[],editing=null,inquiryStatus='all',offset=0,hasMore=false;
async function api(path,method='GET',data){const r=await fetch('/api/admin/'+path,{method,headers:method==='GET'?{}:{'Content-Type':'application/json','X-Ylham-Request':'1'},body:data===undefined?undefined:JSON.stringify(data)});const b=await r.json();if(!r.ok)throw Error(b.error||'Ошибка сервера');return b;}
function notice(message,error=false){$('#notice').textContent=message;$('#notice').className=error?'error':'';}
function label(name,title,value='',type='text',required=false){return `<label>${title}<input name="${name}" type="${type}" value="${esc(value)}" ${required?'required':''} ${type==='number'?'step="any"':''} ${type==='url'?'placeholder="https://… или /assets/…"':''}></label>`;}
function area(name,title,value='',required=false){return `<label>${title}<textarea name="${name}" rows="3" ${required?'required':''}>${esc(value)}</textarea></label>`;}
function select(name,title,value,options){return `<label>${title}<select name="${name}">${Object.entries(options).map(([v,l])=>`<option value="${v}" ${v===value?'selected':''}>${l}</option>`).join('')}</select></label>`;}
function check(name,title,value){return `<label class="check"><input type="checkbox" name="${name}" ${value?'checked':''}>${title}</label>`;}
function langs(d,nameKey='name',descriptionKey='description',required=true){return ['ru','tk','en'].map((l,i)=>`<div class="language-fields"><h3>${['Русский','Türkmençe','English'][i]}</h3>${label(nameKey+'.'+l,nameKey==='title'?'Название видео':'Название',d[nameKey]?.[l]||'','text',required)}${area(descriptionKey+'.'+l,descriptionKey==='address'?'Адрес':'Описание',d[descriptionKey]?.[l]||'',descriptionKey==='address')}</div>`).join('');}
async function load(){
 $('#pageTitle').textContent=titles[section];document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.section===section));$('#view').innerHTML='<p>Загрузка…</p>';$('#toolbar').innerHTML='';
 try{
 if(section==='dashboard'){const d=await api('dashboard');const count=s=>d.counts.find(x=>x.status===s)?.count||0;$('#view').innerHTML=`<div class="metrics"><div class="metric"><b>${count('new')}</b><span>Новых заявок</span></div><div class="metric"><b>${count('processing')}</b><span>В работе</span></div><div class="metric"><b>${d.content.find(x=>x.kind==='product')?.count||0}</b><span>Продуктов в каталоге</span></div></div><div class="panel"><h2>Сайт связан с базой данных</h2><p>Заявки из обеих форм поступают в раздел «Заявки». Здесь можно менять их статус и сохранять внутренние заметки.</p><p>Контакты, товары, магазины, партнёры и видео обновляются на сайте после сохранения. Скрытые записи остаются в админке.</p></div><div class="panel"><h2>Перед публикацией характеристик</h2><p>Заполняйте расход воды, толщину слоя и другие показатели только после подтверждения технологом. Пустые значения на сайте отмечены как уточняемые.</p></div>`;return;}
 if(section==='inquiries'){
 const d=await api('inquiries?status='+inquiryStatus+'&offset='+offset);items=d.items;hasMore=d.hasMore;
 $('#toolbar').innerHTML=`<div class="toolbar">${select('statusFilter','Статус',inquiryStatus,{all:'Все',...statusNames})}<button id="csv" class="secondary">Скачать текущую страницу CSV</button></div>`;
 $('#toolbar select').onchange=e=>{inquiryStatus=e.target.value;offset=0;load();};$('#csv').onclick=exportCSV;
 $('#view').innerHTML=items.length?`<div class="content-list">${items.map(r=>`<article class="row"><div><h3>${esc(r.name)} · ${r.type==='materials'?'Запрос материалов':'Сотрудничество'}</h3><p>${esc(r.contact)}${r.city?' · '+esc(r.city):''}</p><span class="badge ${r.status==='new'?'new':''}">${statusNames[r.status]}</span><p>${new Date(r.created_at).toLocaleString('ru-RU')} · ${r.id.slice(0,8)}</p></div><button class="secondary" data-edit="${r.id}">Открыть</button></article>`).join('')}</div>`:'<div class="empty">В этом разделе пока нет заявок.</div>';
 $('#view').insertAdjacentHTML('beforeend',`<div class="pager"><button id="prev" class="secondary" ${offset===0?'disabled':''}>Назад</button><button id="next" class="secondary" ${!hasMore?'disabled':''}>Следующие</button></div>`);$('#prev').onclick=()=>{offset=Math.max(0,offset-50);load();};$('#next').onclick=()=>{offset+=50;load();};
 }else{
 items=(await api('content?kind='+section)).items;if(section==='product')items.sort((a,b)=>Number(a.data.code)-Number(b.data.code));
 $('#toolbar').innerHTML=section==='settings'?'':`<div class="toolbar"><button id="add" class="primary">Добавить запись</button><span class="hint">${items.length} записей</span></div>`;if($('#add'))$('#add').onclick=()=>openEditor(null);
 $('#view').innerHTML=items.length?`<div class="content-list">${items.map(r=>`<article class="row"><div><h3>${esc(section==='settings'?'Контакты компании':(r.data.code?'YLHAM '+r.data.code+' · ':'')+(r.data.name?.ru||r.data.title?.ru||r.id))}</h3><p>${section==='settings'?esc(r.data.email||'Контакты ещё не заполнены'):esc(r.data.description?.ru||r.data.address?.ru||'')}</p>${section==='settings'?'':`<span class="badge">${r.published?'Показывается на сайте':'Скрыто'}</span>`}</div><button class="secondary" data-edit="${r.id}">Изменить</button></article>`).join('')}</div>`:'<div class="empty">Записей пока нет. Добавьте первую, когда данные будут готовы.</div>';
 }
 document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEditor(items.find(r=>r.id===b.dataset.edit)));
 }catch(e){$('#view').innerHTML='';notice(e.message,true);}
}
function openEditor(record){
 editing=record||{id:section+'-'+crypto.randomUUID().slice(0,12),kind:section,data:{},published:false,version:0};const d=editing.data||{};let html='';$('#editTitle').textContent=section==='inquiries'?'Заявка '+editing.id.slice(0,8):record?'Редактирование':'Новая запись';$('#editorError').textContent='';
 if(section==='inquiries'){
 html=`<div class="detail"><strong>${esc(editing.name)}</strong><p>${esc(editing.contact)}</p><p>${esc(editing.company)} ${esc(editing.city)}</p><p>${esc(editing.message)}</p>${editing.products.map(p=>`<p>YLHAM ${esc(p.code)} · ${esc(p.name)}</p>`).join('')}</div>`+select('status','Статус',editing.status,statusNames)+area('notes','Внутренние заметки',editing.notes);
 }else if(section==='product'){
 html='<div class="field-grid">'+label('code','Код',d.code||'','text',true)+label('weight','Вес мешка, кг',d.weight||25,'number',true)+select('category','Категория',d.category||'adhesive',{adhesive:'Плиточные клеи',floor:'Полы',walls:'Штукатурки',masonry:'Кладка',facade:'Фасады',grout:'Затирки'})+'</div>'+label('image','Изображение: HTTPS или /assets/…',d.image||'/assets/tile.svg','text',true)+check('planned','Выпуск планируется',d.planned)+langs(d)+'<h3>Подтверждённые характеристики</h3><p class="hint">Оставьте поле пустым, если значение ещё не подтверждено.</p><div class="field-grid">'+label('water','Вода, л / мешок',d.specs?.water)+label('consumption','Расход, кг/м²',d.specs?.consumption)+label('layer','Толщина слоя, мм',d.specs?.layer)+label('temperature','Температура нанесения, °C',d.specs?.temperature)+'</div>';
 }else if(section==='store'){
 html=select('city','Город',d.city||'ashgabat',{ashgabat:'Ашхабад',balkanabat:'Балканабат',dashoguz:'Дашогуз',turkmenbashi:'Туркменбаши',turkmenabat:'Туркменабат',mary:'Мары'})+select('type','Формат продаж',d.type||'retail',{retail:'Розничный магазин',office:'Офис продаж',warehouse:'Оптовый склад'})+'<div class="field-grid">'+label('lat','Широта',d.coords?.[0]||'','number',true)+label('lng','Долгота',d.coords?.[1]||'','number',true)+'</div><p class="hint">Укажите точные координаты магазина в Туркменистане, например 37.94 и 58.38.</p>'+label('phone','Телефон',d.phone)+label('url','Сайт магазина (необязательно)',d.url)+langs(d,'name','address');
 }else if(section==='partner'){html=label('logo','Ссылка на логотип (необязательно)',d.logo)+label('url','Сайт партнёра (необязательно)',d.url)+langs(d);}
 else if(section==='video'){html=label('src','HTTPS-ссылка на видеофайл MP4 / WebM',d.src||'','text',true)+label('poster','Ссылка на обложку (необязательно)',d.poster)+langs(d,'title');}
 else if(section==='settings'){html=label('email','Электронная почта',d.email,'email')+label('whatsapp','WhatsApp с кодом страны',d.whatsapp)+label('telegram','Telegram: имя пользователя без @',d.telegram)+label('phone','Телефон',d.phone)+['ru','tk','en'].map((l,i)=>area('address.'+l,'Адрес · '+['Русский','Türkmençe','English'][i],d.address?.[l])).join('');}
 if(!['settings','inquiries'].includes(section))html+=check('published','Показывать на сайте',editing.published);
 $('#fields').innerHTML=html;$('#editor').showModal();
}
$('#editForm').onsubmit=async e=>{e.preventDefault();const form=new FormData(e.currentTarget),get=k=>String(form.get(k)||'').trim(),loc=k=>Object.fromEntries(['ru','tk','en'].map(l=>[l,get(k+'.'+l)]));let d={};$('#save').disabled=true;$('#editorError').textContent='';
 try{
 if(section==='inquiries'){await api('inquiries/'+editing.id,'PUT',{status:get('status'),notes:get('notes'),version:editing.version});}
 else{
 if(section==='product')d={code:get('code'),weight:Number(get('weight')),category:get('category'),image:get('image'),planned:form.has('planned'),name:loc('name'),description:loc('description'),specs:Object.fromEntries(['water','consumption','layer','temperature'].map(k=>[k,get(k)]))};
 if(section==='store')d={city:get('city'),type:get('type'),coords:[Number(get('lat')),Number(get('lng'))],phone:get('phone'),url:get('url'),name:loc('name'),address:loc('address')};
 if(section==='partner')d={logo:get('logo'),url:get('url'),name:loc('name'),description:loc('description')};
 if(section==='video')d={src:get('src'),poster:get('poster'),title:loc('title'),description:loc('description')};
 if(section==='settings')d={email:get('email'),whatsapp:get('whatsapp'),telegram:get('telegram'),phone:get('phone'),address:loc('address')};
 await api('content/'+section+'/'+editing.id,'PUT',{data:d,published:form.has('published'),version:editing.version});
 }
 $('#editor').close();notice('Сохранено в базе данных.');await load();
 }catch(error){$('#editorError').textContent=error.message;}finally{$('#save').disabled=false;}
};
function exportCSV(){const cell=v=>{v=String(v??'');if(/^[=+@\-\t\r]/.test(v))v="'"+v;return '"'+v.replaceAll('"','""')+'"';};const rows=[['ID','Дата','Тип','Имя','Контакт','Компания','Город','Сообщение','Статус'],...items.map(r=>[r.id,r.created_at,r.type,r.name,r.contact,r.company,r.city,r.message,statusNames[r.status]])];const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(r=>r.map(cell).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='ylham-inquiries.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('#closeEditor').onclick=$('#cancelEditor').onclick=()=>$('#editor').close();$('#refresh').onclick=()=>{notice('');load();};document.querySelectorAll('[data-section]').forEach(b=>b.onclick=()=>{section=b.dataset.section;offset=0;notice('');load();});
(async()=>{try{const me=await api('me');$('#account').textContent=me.email;await api('initialize','POST',{});await load();}catch(e){notice(e.message,true);$('#view').innerHTML='<p>Проверьте вход в аккаунт владельца и обновите страницу.</p>';}})();
