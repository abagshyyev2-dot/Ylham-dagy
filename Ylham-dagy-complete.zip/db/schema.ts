import { sqliteTable, text, integer, primaryKey, index } from 'drizzle-orm/sqlite-core';
export const content = sqliteTable('content', {
 kind:text('kind').notNull(), id:text('id').notNull(), data:text('data').notNull(),
 published:integer('published').notNull().default(0), version:integer('version').notNull().default(1),
 createdAt:text('created_at').notNull(), updatedAt:text('updated_at').notNull()
}, t=>[primaryKey({columns:[t.kind,t.id]})]);
export const inquiries = sqliteTable('inquiries', {
 id:text('id').primaryKey(), type:text('type').notNull(), name:text('name').notNull(), contact:text('contact').notNull(),
 company:text('company').notNull().default(''), city:text('city').notNull().default(''), message:text('message').notNull().default(''),
 products:text('products').notNull().default('[]'), status:text('status').notNull().default('new'), notes:text('notes').notNull().default(''),
 version:integer('version').notNull().default(1), createdAt:text('created_at').notNull(), updatedAt:text('updated_at').notNull()
},t=>[index('inquiries_created').on(t.createdAt),index('inquiries_status').on(t.status)]);
export const rateLimits=sqliteTable('rate_limits',{key:text('key').notNull(),bucket:integer('bucket').notNull(),count:integer('count').notNull().default(1)},t=>[primaryKey({columns:[t.key,t.bucket]})]);
export const audit=sqliteTable('audit_log',{id:text('id').primaryKey(),actor:text('actor').notNull(),action:text('action').notNull(),target:text('target').notNull(),createdAt:text('created_at').notNull()});
