import { env } from 'cloudflare:workers';
import { isAdmin } from '../../server/api.mjs';
import adminHTML from '../../server/admin-html.json';
export const dynamic='force-dynamic';
export function GET(request:Request){
 if(!request.headers.get('oai-authenticated-user-id'))return Response.redirect(new URL('/signin-with-chatgpt?return_to=%2Fadmin',request.url),302);
 if(!isAdmin(request,env))return new Response('<!doctype html><meta charset="utf-8"><title>Доступ закрыт</title><h1>Доступ только для владельца сайта</h1><p>Войдите в аккаунт владельца Ylham dagy.</p><a href="/">На сайт</a>',{status:403,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
 return new Response(adminHTML,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' https: data:; connect-src 'self'; form-action 'self'; base-uri 'self'"}});
}
