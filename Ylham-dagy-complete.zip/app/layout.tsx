export const metadata={title:'Ylham dagy',description:'Сухие строительные смеси Ylham dagy'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{children}</body></html>;}
