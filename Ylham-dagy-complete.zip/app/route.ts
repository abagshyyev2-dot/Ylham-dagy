import siteHTML from '../server/site-html.json';
export function GET(){return new Response(siteHTML,{headers:{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff'}});}
